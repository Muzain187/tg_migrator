
from tg_migrator.main import main

main()